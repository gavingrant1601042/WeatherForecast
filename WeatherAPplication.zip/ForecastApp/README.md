# ForecastApp
ForecastApp with .NET Core 

In the directory src\ForecastApp\Config\Constants.cs remember to replace the API Key to yours.
