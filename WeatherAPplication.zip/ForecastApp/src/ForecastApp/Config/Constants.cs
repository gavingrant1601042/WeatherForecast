﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ForecastApp.Config
{
    public static class Constants
    {
        public const string OPEN_WEATHER_APPID = "2d716452512427c5fd5bbfe5262ea00f";
    }
}
